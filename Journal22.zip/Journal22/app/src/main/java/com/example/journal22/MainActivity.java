package com.example.journal22;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;



import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    public static final String EXTRA_MESSAGE = "com.example.myfirstapp.MESSAGE";
    //MyRecyclerViewAdapter adapter;

    private RecyclerView recyclerView;
    private PlanetAdapter adapter;
    private ArrayList<Planet> planetArrayList;


    private static final String LOG_TAG =
            MainActivity.class.getSimpleName();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar myToolbar = (Toolbar) findViewById(R.id.my_toolbar);
        setSupportActionBar(myToolbar);



        recyclerView = (RecyclerView) findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        planetArrayList = new ArrayList<>();
        adapter = new PlanetAdapter(this, planetArrayList);
        recyclerView.setAdapter(adapter);
        createListData();







/*
        // data to populate the RecyclerView with
        ArrayList<String> animalNames = new ArrayList<>();
        animalNames.add("Horse");
        animalNames.add("Cow");
        animalNames.add("Camel");
        animalNames.add("Sheep");
        animalNames.add("Goat");

        // set up the RecyclerView
        RecyclerView recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new MyRecyclerViewAdapter(this, animalNames);
        //adapter.setClickListener(this);
        recyclerView.setAdapter(adapter);
*/
    }
    private void createListData() {
        Planet planet = new Planet("Title1", "ContentContent", 10, 12750);
        planetArrayList.add(planet);
        planet = new Planet("Title2", "ContentContent", 26, 143000);
        planetArrayList.add(planet);
        planet = new Planet("Title3", "ContentContent", 4, 6800);
        planetArrayList.add(planet);
        planet = new Planet("Title4", "ContentContent", 1, 2320);
        planetArrayList.add(planet);
        planet = new Planet("Title5", "ContentContent", 9, 12750);
        planetArrayList.add(planet);
        planet = new Planet("Title6", "ContentContent", 11, 120000);
        planetArrayList.add(planet);
        planet = new Planet("Title7", "ContentContent", 4, 4900);
        planetArrayList.add(planet);
        planet = new Planet("Title8", "ContentContent", 12, 50500);
        planetArrayList.add(planet);
        planet = new Planet("Title9", "ContentContent", 9, 52400);
        planetArrayList.add(planet);
        adapter.notifyDataSetChanged();
    }


 //   public void onItemClick(View view, int position) {
 //       Toast.makeText(this, "You clicked " + adapter.getItem(position) + " on row number " + position, Toast.LENGTH_SHORT).show();
 //   }



}